import React from 'react'
import { useEffect , useState } from 'react'

function Users() {
  const [users , setUsers] = useState([]);

  useEffect(() =>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then(res => res.json())
        .then(data => setUsers(data))
  } , [])
  
    return (
    <div>
        <h2> User_List</h2> <hr/>
        {users.map(i=>(
            <p key = {i.id}> {i.name}</p>
            ))} 
    </div>
  )

}

export default Users