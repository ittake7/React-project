import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div style={{
      backgroundColor: "black",
      display: "flex",
      gap: "20px",
      padding: "15px"
    }}>

      <Link to="/" style={{ color: "yellow" }}>Home</Link>
      <Link to="/users" style={{ color: "yellow" }}>Users</Link>

    </div>
  );
}

export default Navbar;