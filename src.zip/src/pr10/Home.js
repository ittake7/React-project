import React from 'react'

function Home() {
  return (
    <div>
        <h1>Welcome To the Home Page </h1>
        <h2>My name Is Aryan </h2>
        <h2> I complete Practical 10 </h2>
    </div>
  )
}

export default Home