import './App.css';
import FunctionalComponentForm from './FunctionalComponentForm';
import ClassComponentForm from './ClassComponentForm';

function App() {
  return (
    <div className="App">
      <h1>Controlled Forms in React</h1>

      <FunctionalComponentForm />
      <hr />
      <ClassComponentForm />
    </div>
  );
}

export default App;