import React, { useState } from "react";

function App() {

  const [count, setCount] = useState(0);
  const [name, setName] = useState("");
  const [isVisible, setIsVisible] = useState(true);
  const [user, setUser] = useState({
    age: 23,
    city: "Ahmedabad"
  });

  const increment = () => {
    setCount(prev => prev + 1);
  };

  const decrement = () => {
    setCount(prev => prev - 1);
  };

  const toggleText = () => {
    setIsVisible(prev => !prev);
  };

  const updateCity = () => {
    setUser(prev => ({
      ...prev,
      city: "Palanpur"
    }));
  };

  const resetAll = () => {
    setCount(0);
    setName("");
    setIsVisible(true);
    setUser({ age: 20, city: "Ahmedabad" });
  };

  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h2>Practical 07 - State Demo</h2>

      <h3>Counter: {count}</h3>
      <button onClick={increment}>Increment</button>
      <button onClick={decrement}>Decrement</button>

      <hr />

      <h3>Enter Name:</h3>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <p>Your Name: {name}</p>

      <hr />

      <button onClick={toggleText}>Toggle Text</button>
      {isVisible && <p>This text is visible</p>}

      <hr />

      <h3>User Info</h3>
      <p>Age: {user.age}</p>
      <p>City: {user.city}</p>
      <button onClick={updateCity}>Change City</button>

      <hr />

      <button onClick={resetAll}>Reset All</button>
    </div>
  );
}

export default App;