import React from "react";

function Welcome(props) {
  return <h1>Hello, {props.name}!</h1>;
}

function Button({ label }) {
  return (
    <button style={{
      padding: "10px 20px",
      margin: "10px",
      fontSize: "16px",
      cursor: "pointer"
    }}>
      {label}
    </button>
  );
}

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h2>Welcome To React Props Practical06</h2>

      {/* Welcome Component */}
      <Welcome name="Kashish Bansal" />
      <Welcome name="Aryan Lunechiya" />

      {/* Button Component */}
      <Button label="Login" />
      <Button label="Register" />
      <Button label="Subscribe" />

    </div>
  );
}

export default App;