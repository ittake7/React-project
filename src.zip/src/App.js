import React from "react";
import { Routes, Route } from "react-router-dom";

import Navbar from "./pr10/Navbar";
import Home from "./pr10/Home";
import Users from "./pr10/Users";

function App() {
  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/users" element={<Users />} />
      </Routes>
    </>
  );
}

export default App;