import React, { Component } from "react";

class ClassComponentForm extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: "",
      email: "",
      password: ""
    };
  }

  handleChange = (e) => {
    const { name, value } = e.target;

    this.setState({
      [name]: value
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    alert(`Name: ${this.state.name}, Email: ${this.state.email}`);
  };

  render() {
    return (
      <div>
        <h2>Class Component Form</h2>

        <form onSubmit={this.handleSubmit}>
          <input
            type="text"
            name="name"
            placeholder="Enter Name"
            value={this.state.name}
            onChange={this.handleChange}
          />
          <br /><br />

          <input
            type="email"
            name="email"
            placeholder="Enter Email"
            value={this.state.email}
            onChange={this.handleChange}
          />
          <br /><br />

          <input
            type="password"
            name="password"
            placeholder="Enter Password"
            value={this.state.password}
            onChange={this.handleChange}
          />
          <br /><br />

          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default ClassComponentForm;