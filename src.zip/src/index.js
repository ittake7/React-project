const express = require(express);
const app = express();

user = {id: "01" , name:"aryan" , salary: "20000", deparment: "CSE",
        id: "02" , name:"krinap" , salary: "30000", deparment: "CSE",
        id: "03" , name:"krunal" , salary: "40000", deparment: "CSE"
        };

app.use = express.json();

// get api
app.get("/api", (req,res) => {
    res.send("hello from Api");
});

// post
app.post()("/api", (req,res) => {
    use:data(req.body);
    res.send({
        message: "Data Received"
    });
});

//server
app.get("/api", (req,res) => {
    
    res.send(3000)({
        massage: "Server is running on 3000 port"
    });
    
});

